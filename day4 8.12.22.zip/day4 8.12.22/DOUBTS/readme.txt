diffrent size image align
absolute